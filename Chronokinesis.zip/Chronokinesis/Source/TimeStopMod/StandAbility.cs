﻿using AbilityUser;
using RimWorld;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Verse;
using UnityEngine;

namespace TimeStopMod 
{

    public class StandAbility : PawnAbility
	{

    }
}
