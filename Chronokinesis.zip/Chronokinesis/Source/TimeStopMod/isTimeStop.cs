using System;

namespace ControlTimeMod
{
	public enum isTimeStop : byte
	{
		Paused,
		Normal
	}
}
