﻿using System;

namespace ControlTimeMod
{
	public static class CheckStopTime
	{
		public static isTimeStop curTimeSpeed = isTimeStop.Normal;
	}
}

